# tarea4ans

para ejecutar

python3 main.py
