from sympy import *
import math
x = Symbol('x')
def simpadapta(a,b,cf,fn):

    """
     a = limite inferior
     b = limite superior
     cf = cifra significativa para encontrar la tolerancia
     fn = funcion
    """
    c=(a+b)/2
    e=10**(-cf)
    ajuste=[]
    matriz=[[a][b]
    [a][c]
    [c][b]]
    i=0
    for i in range(2):
        ajuste.append((matriz[i][1]-matriz[i][0])/6)*(fn.subs(x,matriz[i][0])+fn.subs(x,matriz[i][1])+4*fn.subs(x,(matriz[i][0]+matriz[i][0])/2))
    suma=abs(ajuste[i]+ajuste[i-1]-ajuste[i-2])/15
    if suma<e:
        integracion=(16*(ajuste[i]+ajuste[i-1]-ajuste[i-2]))/15
    else:
        return "valor no resuelto"
    return integracion
