from sympy import *

x=Symbol('x')



#print(integralReal(x,1,2))
