from sympy import *
import math

def rosemberg(a,b,nivel,fn):
    x = symbols('x')
    """
     a = limite inferior
     b = limite superior
     nivel = nivel 
     fn = funcion
    """
    nivel1=[]
    i=1
    for i in range(nivel):
        h=(b-a)/(2**(i-1))
        intervalos=[]
        intervalos[0]=a
        j=1
        while intervalos[j-1]<b:
            intervalos.append(intervalos[j-1]+h)
            j+1
        suma=0
        if (len(intervalos)<=2):
            l=1
            for l in range(len(intervalos)-2):
                suma=suma+fn.subs(x,intervalos[l])
        nivel1.append(((b-a)/(2**i))*(fn.subs(x,a)+2*suma+fn.subs(b)))
    i=2
    for i in range(nivel):
        nivelx=[]
        j=1
        for j in range(len(nivel1)):
            nivelx.append(((4**j)/((4**j)-1))*(nivel1[j])-(1/((4**j)-1))*(nivel1[j-1]))
        nivel1=[]
        nivel1.append(nivelx)
    return nivelx[0]