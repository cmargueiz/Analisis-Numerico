from sympy import *
import math

def simpsons13c(a,b,fn,n):
    x = symbols('x')
    """
     a = limite inferior
     b = limite superior
     n = intervalo
     fn = funcion
    """
    h=(b-a)/2
    xi = []
    xi.append(a)
    i=1
    for i in range(n):
        xi.append(xi[i-1]+h)
    j=1
    suma=0
    for j in range(n-1):
        suma=suma+fn.subs(x,xi[i])
    xm=[]
    i=1
    for i in range(n):
        xm.append((xi[i]+xi[i-1])/2)
    j=0
    suma2=0
    for j in range(n-1):
        suma2=suma2+fn.subs(x,xm[j])
    integral=(b-a)*((fn.subs(x,a)+4*suma2+2*suma+fn.subs(x,b))/(6*n))   
    return integral