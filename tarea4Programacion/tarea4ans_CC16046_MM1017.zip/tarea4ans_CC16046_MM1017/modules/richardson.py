from sympy import *


x=Symbol('x')

def calcularh(h,n):
    hs=[h]
    
    for i in range(0,n):
        hs.append(h/2)
        h=h/2
    return hs

def formula(mayor,menor,nivel):
    return ((4**(nivel-1))*(mayor)-(menor))/(4**(nivel-1)-1)

def orden2(x0,h,f):
    return (f.subs(x,x0+h)-f.subs(x,x0-h))/(2*h)


def richarson(x0,f,h,niveles):
    richarson=[]
    nivelx=[]

    for i in range(0,niveles):
        if i==0:
            for j in calcularh(h,niveles-1):
                nivelx.append(orden2(x0,j,f))
            richarson.append(nivelx)
            nivelx=[]
        else:
            for j in range(0,len(richarson[i-1])-1):
                nivelx.append(formula(richarson[i-1][j+1],richarson[i-1][j],i+1))
            richarson.append(nivelx)
            nivelx=[]

    return richarson[len(richarson)-1][0]


print(richarson(2,x**2,1,4))