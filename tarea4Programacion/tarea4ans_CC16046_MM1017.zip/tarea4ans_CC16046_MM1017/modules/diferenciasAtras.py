from sympy import *
x=Symbol('x')

def dx1(x0,h,f):
    return (f.subs(x,x0)-f.subs(x,x0-h))/h

def dx2(x0,h,f):
    return (3*f.subs(x,x0)-4*f.subs(x,x0-h)+f.subs(x,x0-2*h))/(2*h)

#DERIVADAS DE ORDEN SUPERIOR PRIMERA DIFERENCIA

def dxx1(x0,h,f):
    return (f.subs(x,x0)-2*f.subs(x,x0-h)+f.subs(x,x0+2*h))/h**2

def dxxx1(x0,h,f):
    return (f.subs(x,x0)-3*f.subs(x,x0+2*h)-f.subs(x,x0-3*h))/h**3

def dlv1(x0,h,f):
    return (f.subs(x,x0)-4*f.subs(x,x0-h)+6*f.subs(x,x0-2*h)-4*f.subs(x,x0-3*h)+f.subs(x,x0-4*h))/h**4

#DERIVADAS DE ORDEN SUPERIOr SEGUNDA DIFERENCIA

def dxx2(x0,h,f):
    return (2*f.subs(x,x0)-5*f.subs(x,x0-h)+4*f.subs(x,x0-2*h)-f.subs(x,x0-3*h))/h**2

def dxxx2(x0,h,f):
    return (5*f.subs(x,x0)-18*f.subs(x,x0-h)+24*f.subs(x,x0-2*h)-14*f.subs(x,x0-3*h)+3*f.subs(x,x0-4*h))/h**3

def dlv2(x0,h,f):
    return (3*f.subs(x,x0)-14*f.subs(x,x0-h)+26*f.subs(x,x0-2*h)-24*f.subs(x,x0-3*h)+11*f.subs(x,x0-4*h)-2*f.subs(x,x0-5*h))/h**4

