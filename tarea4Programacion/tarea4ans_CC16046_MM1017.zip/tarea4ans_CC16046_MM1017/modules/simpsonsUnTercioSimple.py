from sympy import *
import math

def simpsons13s(a,b,fn):
    x = symbols('x')
    """
     a = limite inferior
     b = limite superior
     fn = funcion
    """
    xm=(b+a)/2
    integral=(b-a)*((fn.subs(x,a)+4*fn.subs(x,xm)+fn.subs(x,b))/6)
    return integral