from sympy import *
import math
x = symbols('x')
def simpsons18c(a,b,fn,n):
    
    """
     a = limite inferior
     b = limite superior
     n = intervalo
     fn = funcion
    """
    h=(b-a)/3
    xi = []
    xi.append(a)
    n=round((b-a)/h)
    
    i=1
    for i in range(n):
        xi.append(xi[i]+h)
    j=1
    
    suma=0
    for j in range(n):
        suma=suma+fn.subs(x,xi[j])
    xm=[]
    
    i=0
    for l in range(0,len(xi)-1):
        xm.append(xi[l]+1/3)
        xm.append(xi[l]+2/3)
    j=0
    
    suma2=0
    for j in range(0,len(xm)):
        suma2=suma2+fn.subs(x,xm[j])
    integral=((b-a)/(8*n))*((fn.subs(x,a)+3*suma2+2*suma+fn.subs(x,b)))   
    return integral
