from sympy import *
import math
x = Symbol('x')
def trapecios(a,b,fn):

    """
     a = limite inferior
     b = limite superior
     fn = funcion
    """
    integral=(b-a)*((fn.subs(x,a)+fn.subs(x,b))/2)   
    return integral
