from sympy import *
x=Symbol('x')

def orden2(x0,h,f):
    return (f.subs(x,x0+h)-f.subs(x,x0-h))/(2*h)

def orden4(x0,h,f):
    return (-f.subs(x,x0+2*h)+8*f.subs(x,x0+h)-8*f.subs(x,x0-h)+f.subs(x,x0-2*h))/(12*h)

def tresPuntos(x0,h,f):
    return (-3*f.subs(x,x0)+4*f.subs(x,x0+h)-f.subs(x,x0+2*h))/(2*h)

def cincoPuntos(x0,h,f):
    return (-25*f.subs(x,x0)+48*f.subs(x,x0+h)-36*f.subs(x,x0+2*h)+16*f.subs(x,x0+3*h)-3*f.subs(x,x0+4*h))/(12*h)

#DERIVADAS DE ORDEN SUPERIOR POR PRIMERA DIFERENCIA
def dxx1(x0,h,f):
    return (f.subs(x,x0+h)-2*f.subs(x,x0)+f.subs(x,x0))/h**2

def dxxx1(x0,h,f):
    return (f.subs(x,x0+2*h)-2*f.subs(x,x0+h)+2*f.subs(x,x0-h)-f.subs(x,x0-2*h))/(2*h**3)

def dlv1(x0,h,f):
    return (f.subs(x,x0+2*h)-4*f.subs(x,x0+h)+6*f.subs(x,x0)-4*f.subs(x,x0-h)+f.subs(x,x0-2*h))/h**4

#DERIVADAS DE ORDEN SUPEPERIOR POR SEGUNDA DIFERENCIA
def dxx2(x0,h,f):
    return (-f.subs(x,x0+2*h)+16*f.subs(x,x0+h)-30*f.subs(x,x0)+16*f.subs(x,x0-h)-f.subs(x,x0-2*h))/(12*h**2)

def dxxx2(x0,h,f):
    return (-f.subs(x,x0+3*h)+8*f.subs(x,x0+2*h)-12*f.subs(x,x0+h)+12*f.subs(x,x0-h)-8*f.subs(x,x0-2*h)+f.subs(x,x0-3*h))/(8*h**3)

def dlv2(x0,h,f):
    return (-f.subs(x,x0+3*h)+12*f.subs(x,x0+2*h)-39*f.subs(x,x0+h)+56*f.subs(x,x0)-39*f.subs(x,x0-h)+12*f.subs(x,x0-2*h)-f.subs(x,x0-3*h))/(6*h**4)

