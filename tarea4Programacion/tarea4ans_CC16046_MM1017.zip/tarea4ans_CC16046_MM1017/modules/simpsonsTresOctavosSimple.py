from sympy import *
import math

def simpsons18s(a,b,fn):
    x = symbols('x')
    """
     a = limite inferior
     b = limite superior
     fn = funcion
    """
    h=(b-a)/3
    integral=(b-a)*((fn.subs(x,a)+3*fn.subs(x,a+h)+3*fn.subs(x,a+h+h)+fn.subs(x,b))/8)
    return integral