from sympy import *
import math

def trapecioc(a,b,fn,n):
    x = symbols('x')
    """
     a = limite inferior
     b = limite superior
     n = intervalo
     fn = funcion
    """
    h=(b-a)/2
    xi = []
    xi.append(a)
    i=1
    for i in range(n):
        xi.append(xi[i-1]+h)
    j=1
    suma=0
    for j in range(n-1):
        suma=suma+fn.subs(x,xi[j])
    integral=(b-a)*((fn.subs(x,a)+2*suma+fn.subs(x,b))/(2*n))   
    return integral
