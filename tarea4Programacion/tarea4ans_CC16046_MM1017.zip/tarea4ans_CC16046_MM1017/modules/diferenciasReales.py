from sympy import *
x = symbols('x')

def nDerivada(fx,n,x0):
    """
    fx -- Funcion que se esta derivando
    n -- Numero de la derivada de orden superior que se desea encontrar, si es primera derivada colocar 1
    x0 -- Valor que se desea evaluar
    """
    for i in range(0,n):
        fx=diff(fx,x)
    return fx.subs(x,x0)

def integralReal(f,a,b):
    return integrate(f,(x,a,b))

def errorPorcentual(valorReal, valorAprox):
    return str((abs(valorReal-valorAprox)/valorReal)*100)

