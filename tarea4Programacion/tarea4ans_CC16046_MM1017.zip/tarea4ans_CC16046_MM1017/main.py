from tkinter import *
from tkinter import ttk, messagebox
import tkinter.font as Font
from modules.diferenciasReales import *

import modules.diferenciasAdelante as adelante
import modules.centradas as centrada
import modules.diferenciasAtras as atras
import modules.richardson as ric

from modules.trapecioSimple import *
from modules.trapecioCompuesto import *
from modules.simpsonsUnTercioSimple import *
from modules.simpsonsUnTercioCompuesto import *
from modules.simpsonsTresOctavosSimple import *
from modules.simpsonsTresOctavosCompuesto import *


root = Tk()
root.title("DIFERENCIACION E INTEGRACION NUMERICA")
#root.geometry('450x450')

#Variables
proceso= ["Seleccione...","Derivar","Integrar"]
numeroDerivada=["","1","2","3","4"]
metodo=[]


funcion=StringVar()
#variables para derivar
h=StringVar()
x0=StringVar()
niveles=StringVar()
#variables chk para derivar
chkdx1Adelante=IntVar()
chkdx2Adelante=IntVar()
chkdx1Atras=IntVar()
chkdx2Atras=IntVar()
chkRichar=IntVar()
chkdxx1Adelante=IntVar()
chkdxx2Adelante=IntVar()
chkdxx1Atras=IntVar()
chkdxx2Atras=IntVar()
chkdxx1Centrada=IntVar()
chkdxx2Centrada=IntVar()
chkdxxx1Adelante=IntVar()
chkdxxx2Adelante=IntVar()
chkdxxx1Atras=IntVar()
chkdxxx2Atras=IntVar()
chkdxxx1Centrada=IntVar()
chkdxxx2Centrada=IntVar()
chkdlv1Adelante=IntVar()
chkdlv2Adelante=IntVar()
chkdlv1Atras=IntVar()
chkdlv2Atras=IntVar()
chkdlv1Centrada=IntVar()
chkdlv2Centrada=IntVar()
chkorden2=IntVar()
chkorden4=IntVar()
chk3=IntVar()
chk5=IntVar()

#variables chk para los metodos de integracion
chkTrapecioSimple=IntVar()
chkTrapecioCompuesto=IntVar()
chkTercioSimple=IntVar()
chkTercioCompuesto=IntVar()
chkOctavoSimple=IntVar()
chkOctavoCompuesto=IntVar()
chkRosember=IntVar()
chkCuadratura=IntVar()
chkAdaptativo=IntVar()
#variables para intergrar
limiteSuperior=StringVar()
limiteInferior=StringVar()
intervalos=StringVar()


#Metodos
def seleccionarProceso(event):
    if cmbProceso.get()=="Derivar":
        frameIntegracion.pack_forget()
        frameDiferenciacion.pack(side=TOP)
        frameDatos.pack()
        frameDiferenciasSuperior.pack()
        limpiar()
            
    elif cmbProceso.get()=="Integrar":
        frameDiferenciacion.pack_forget()
        frameIntegracion.pack(side=TOP)
        frameDiferenciasSuperior.pack_forget()
        frameDatos.pack_forget()
        cmbDerivada.current(0)
        limpiar()
    else:
        messagebox.showerror("Error","Debe seleccionar una operacion para continuar con el proceso")


def seleccionarNDerivada(event):
    if cmbDerivada.get()=="1":
        framePrimeraDerivada.pack()
        
        frameSegundaDerivada.pack_forget()
        frameTerceraDerivada.pack_forget()
        frameCuartaDerivada.pack_forget()
        
    elif cmbDerivada.get()=="2":
        framePrimeraDerivada.pack_forget()
        frameSegundaDerivada.pack(side=TOP)
        frameTerceraDerivada.pack_forget()
        frameCuartaDerivada.pack_forget()
        
    elif cmbDerivada.get()=="3":
        framePrimeraDerivada.pack_forget()
        frameSegundaDerivada.pack_forget()
        frameTerceraDerivada.pack(side=TOP)
        frameCuartaDerivada.pack_forget()
        
    elif cmbDerivada.get()=="4":
        framePrimeraDerivada.pack_forget()
        frameSegundaDerivada.pack_forget()
        frameTerceraDerivada.pack_forget()
        frameCuartaDerivada.pack(side=TOP)
        
    else:
         messagebox.showerror("Error","Debe seleccionar el numero de la derivada para continuar con el proceso")


def procesarCalculo():
    
    if(h!="" and x0!="" and funcion!=""):

        if chkdx1Adelante.get()==1:
            error=errorPorcentual(nDerivada(eval(funcion.get()),1,float(x0.get())),adelante.dx1(float(x0.get()),float(h.get()),eval(funcion.get())))
            ingreso=["1era Diferencia hacia adelante",str(adelante.dx1(float(x0.get()),float(h.get()),eval(funcion.get()))),str(nDerivada(eval(funcion.get()),1,float(x0.get()))),error]
            metodo.append(ingreso)
        if chkdx2Adelante.get()==1:
            error=errorPorcentual(nDerivada(eval(funcion.get()),1,float(x0.get())),adelante.dx2(float(x0.get()),float(h.get()),eval(funcion.get())))
            ingreso=["2da Diferencia hacia adelante",str(adelante.dx2(float(x0.get()),float(h.get()),eval(funcion.get()))),str(nDerivada(eval(funcion.get()),1,float(x0.get()))),error]
            metodo.append(ingreso)
        if chkorden2.get()==1:
            valorAproximado=str(centrada.orden2(float(x0.get()),float(h.get()),eval(funcion.get())))
            valorReal=str(nDerivada(eval(funcion.get()),1,float(x0.get())))
            error=errorPorcentual(float(valorReal),float(valorAproximado))
            ingreso=["Diferencia Centrada de orden2",valorAproximado,valorReal,error]
            metodo.append(ingreso)
        if chkorden4.get()==1:
            valorAproximado=str(centrada.orden4(float(x0.get()),float(h.get()),eval(funcion.get())))
            valorReal=str(nDerivada(eval(funcion.get()),1,float(x0.get())))
            error=errorPorcentual(float(valorReal),float(valorAproximado))
            ingreso=["Diferencia Centrada de orden4",valorAproximado,valorReal,error]
            metodo.append(ingreso)
        if chk3.get()==1:
            valorAproximado=str(centrada.tresPuntos(float(x0.get()),float(h.get()),eval(funcion.get())))
            valorReal=str(nDerivada(eval(funcion.get()),1,float(x0.get())))
            error=errorPorcentual(float(valorReal),float(valorAproximado))
            ingreso=["Difenciacion con 3 Puntos",valorAproximado,valorReal,error]
            metodo.append(ingreso)
        if chk5.get()==1:
            valorAproximado=str(centrada.cincoPuntos(float(x0.get()),float(h.get()),eval(funcion.get())))
            valorReal=str(nDerivada(eval(funcion.get()),1,float(x0.get())))
            error=errorPorcentual(float(valorReal),float(valorAproximado))
            ingreso=["Diferenciacion con 5 Puntos",valorAproximado,valorReal,error]
            metodo.append(ingreso)
        if chkdx1Atras.get()==1:
            valorAproximado=str(atras.dx1(float(x0.get()),float(h.get()),eval(funcion.get())))
            valorReal=str(nDerivada(eval(funcion.get()),1,float(x0.get())))
            error=errorPorcentual(float(valorReal),float(valorAproximado))
            ingreso=["1era Diferencia atras",valorAproximado,valorReal,error]
            metodo.append(ingreso)
        if chkdx2Atras.get()==1:
            valorAproximado=str(atras.dx2(float(x0.get()),float(h.get()),eval(funcion.get())))
            valorReal=str(nDerivada(eval(funcion.get()),1,float(x0.get())))
            error=errorPorcentual(float(valorReal),float(valorAproximado))
            ingreso=["2da Diferencia atras",valorAproximado,valorReal,error]
            metodo.append(ingreso)
        if chkRichar.get()==1:
            if niveles.get()!="":
                valorAproximado=str(ric.richarson(float(x0.get()),eval(funcion.get()),float(h.get()),int(niveles.get())))
                valorReal=str(nDerivada(eval(funcion.get()),1,float(x0.get())))
                error=errorPorcentual(float(valorReal),float(valorAproximado))
                ingreso=["Diferenciacion por Richarson",valorAproximado,valorReal,error]
                metodo.append(ingreso)
            else:
                messagebox.showerror("Error","Debe completar los campos")
        if chkdxx1Adelante.get()==1:
            valorAproximado=str(adelante.dxx1(float(x0.get()),float(h.get()),eval(funcion.get())))
            valorReal=str(nDerivada(eval(funcion.get()),2,float(x0.get())))
            error=errorPorcentual(float(valorReal),float(valorAproximado))
            ingreso=["2da Derivada por 1era Diferencia adelante",valorAproximado,valorReal,error]
            metodo.append(ingreso)
        if chkdxx2Adelante.get()==1:
            valorAproximado=str(adelante.dxx2(float(x0.get()),float(h.get()),eval(funcion.get())))
            valorReal=str(nDerivada(eval(funcion.get()),2,float(x0.get())))
            error=errorPorcentual(float(valorReal),float(valorAproximado))
            ingreso=["2da Derivada por 2da Diferencia adelante",valorAproximado,valorReal,error]
            metodo.append(ingreso)
        if chkdxx1Centrada.get()==1:
            valorAproximado=str(centrada.dxx1(float(x0.get()),float(h.get()),eval(funcion.get())))
            valorReal=str(nDerivada(eval(funcion.get()),2,float(x0.get())))
            error=errorPorcentual(float(valorReal),float(valorAproximado))
            ingreso=["2da Derivada por 1era Diferencia centrada",valorAproximado,valorReal,error]
            metodo.append(ingreso)
        if chkdxx2Centrada.get()==1:
            valorAproximado=str(centrada.dxx2(float(x0.get()),float(h.get()),eval(funcion.get())))
            valorReal=str(nDerivada(eval(funcion.get()),2,float(x0.get())))
            error=errorPorcentual(float(valorReal),float(valorAproximado))
            ingreso=["2da Derivada por 2da Diferencia centrada",valorAproximado,valorReal,error]
            metodo.append(ingreso)
        if chkdxx1Atras.get()==1:
            valorAproximado=str(atras.dxx1(float(x0.get()),float(h.get()),eval(funcion.get())))
            valorReal=str(nDerivada(eval(funcion.get()),2,float(x0.get())))
            error=errorPorcentual(float(valorReal),float(valorAproximado))
            ingreso=["2da Derivada por 1era Diferencia atras",valorAproximado,valorReal,error]
            metodo.append(ingreso)
        if chkdxx2Atras.get()==1:
            valorAproximado=str(atras.dxx2(float(x0.get()),float(h.get()),eval(funcion.get())))
            valorReal=str(nDerivada(eval(funcion.get()),2,float(x0.get())))
            error=errorPorcentual(float(valorReal),float(valorAproximado))
            ingreso=["2da Derivada por 2da Diferencia atras",valorAproximado,valorReal,error]
            metodo.append(ingreso)
            #---
        if chkdxxx1Adelante.get()==1:
            valorAproximado=str(adelante.dxxx1(float(x0.get()),float(h.get()),eval(funcion.get())))
            valorReal=str(nDerivada(eval(funcion.get()),3,float(x0.get())))
            error=errorPorcentual(float(valorReal),float(valorAproximado))
            ingreso=["3ra Derivada por 1era Diferencia adelante",valorAproximado,valorReal,error]
            metodo.append(ingreso)
        if chkdxxx2Adelante.get()==1:
            valorAproximado=str(adelante.dxxx2(float(x0.get()),float(h.get()),eval(funcion.get())))
            valorReal=str(nDerivada(eval(funcion.get()),3,float(x0.get())))
            error=errorPorcentual(float(valorReal),float(valorAproximado))
            ingreso=["3ra Derivada por 2da Diferencia adelante",valorAproximado,valorReal,error]
            metodo.append(ingreso)
        if chkdxxx1Centrada.get()==1:
            valorAproximado=str(centrada.dxxx1(float(x0.get()),float(h.get()),eval(funcion.get())))
            valorReal=str(nDerivada(eval(funcion.get()),3,float(x0.get())))
            error=errorPorcentual(float(valorReal),float(valorAproximado))
            ingreso=["3ra Derivada por 1era Diferencia centrada",valorAproximado,valorReal,error]
            metodo.append(ingreso)
        if chkdxxx2Centrada.get()==1:
            valorAproximado=str(centrada.dxxx2(float(x0.get()),float(h.get()),eval(funcion.get())))
            valorReal=str(nDerivada(eval(funcion.get()),3,float(x0.get())))
            error=errorPorcentual(float(valorReal),float(valorAproximado))
            ingreso=["3ra Derivada por 2da Diferencia centrada",valorAproximado,valorReal,error]
            metodo.append(ingreso)
        if chkdxxx1Atras.get()==1:
            valorAproximado=str(atras.dxxx1(float(x0.get()),float(h.get()),eval(funcion.get())))
            valorReal=str(nDerivada(eval(funcion.get()),3,float(x0.get())))
            error=errorPorcentual(float(valorReal),float(valorAproximado))
            ingreso=["3ra Derivada por 1era Diferencia atras",valorAproximado,valorReal,error]
            metodo.append(ingreso)
        if chkdxxx2Atras.get()==1:
            valorAproximado=str(atras.dxxx2(float(x0.get()),float(h.get()),eval(funcion.get())))
            valorReal=str(nDerivada(eval(funcion.get()),3,float(x0.get())))
            error=errorPorcentual(float(valorReal),float(valorAproximado))
            ingreso=["3ra Derivada por 2da Diferencia atras",valorAproximado,valorReal,error]
            metodo.append(ingreso)
            #----- para cuarta derivada
        if chkdlv1Adelante.get()==1:
            valorAproximado=str(adelante.dlv1(float(x0.get()),float(h.get()),eval(funcion.get())))
            valorReal=str(nDerivada(eval(funcion.get()),4,float(x0.get())))
            error=errorPorcentual(float(valorReal),float(valorAproximado))
            ingreso=["4ta Derivada por 1era Diferencia adelante",valorAproximado,valorReal,error]
            metodo.append(ingreso)
        if chkdlv2Adelante.get()==1:
            valorAproximado=str(adelante.dlv2(float(x0.get()),float(h.get()),eval(funcion.get())))
            valorReal=str(nDerivada(eval(funcion.get()),4,float(x0.get())))
            error=errorPorcentual(float(valorReal),float(valorAproximado))
            ingreso=["4ta Derivada por 2da Diferencia adelante",valorAproximado,valorReal,error]
            metodo.append(ingreso)
        if chkdlv1Centrada.get()==1:
            valorAproximado=str(centrada.dlv1(float(x0.get()),float(h.get()),eval(funcion.get())))
            valorReal=str(nDerivada(eval(funcion.get()),4,float(x0.get())))
            error=errorPorcentual(float(valorReal),float(valorAproximado))
            ingreso=["4ta Derivada por 1era Diferencia centrada",valorAproximado,valorReal,error]
            metodo.append(ingreso)
        if chkdlv2Centrada.get()==1:
            valorAproximado=str(centrada.dlv2(float(x0.get()),float(h.get()),eval(funcion.get())))
            valorReal=str(nDerivada(eval(funcion.get()),4,float(x0.get())))
            error=errorPorcentual(float(valorReal),float(valorAproximado))
            ingreso=["4ta Derivada por 2da Diferencia centrada",valorAproximado,valorReal,error]
            metodo.append(ingreso)
        if chkdlv1Atras.get()==1:
            valorAproximado=str(atras.dlv1(float(x0.get()),float(h.get()),eval(funcion.get())))
            valorReal=str(nDerivada(eval(funcion.get()),3,float(x0.get())))
            error=errorPorcentual(float(valorReal),float(valorAproximado))
            ingreso=["4ta Derivada por 1era Diferencia atras",valorAproximado,valorReal,error]
            metodo.append(ingreso)
        if chkdlv2Atras.get()==1:
            valorAproximado=str(atras.dlv2(float(x0.get()),float(h.get()),eval(funcion.get())))
            valorReal=str(nDerivada(eval(funcion.get()),3,float(x0.get())))
            error=errorPorcentual(float(valorReal),float(valorAproximado))
            ingreso=["4ta Derivada por 2da Diferencia atras",valorAproximado,valorReal,error]
            metodo.append(ingreso)
        if chkTrapecioSimple.get()==1:
            valorAproximado=trapecios(float(limiteInferior.get()),float(limiteSuperior.get()),eval(funcion.get()))
            valorReal=integralReal(eval(funcion.get()),float(limiteInferior.get()),float(limiteSuperior.get()))
            error=errorPorcentual(float(valorReal),float(valorAproximado))
            ingreso=["Trapecio Simple",valorAproximado,valorReal,error]
            metodo.append(ingreso)
        if chkTrapecioCompuesto.get()==1:
            if (limiteSuperior.get()!="" and limiteInferior.get()!="") and intervalos.get()!="":
                valorAproximado=trapecioc(float(limiteInferior.get()),float(limiteSuperior.get()),eval(funcion.get()),int(intervalos.get()))
                valorReal=integralReal(eval(funcion.get()),float(limiteInferior.get()),float(limiteSuperior.get()))
                error=errorPorcentual(float(valorReal),float(valorAproximado))
                ingreso=["Trapecio Compuesto",valorAproximado,valorReal,error]
                metodo.append(ingreso)
            else:
                messagebox.showerror("Error","Debe completar los campos")
        if chkTercioSimple.get()==1:
            valorAproximado=simpsons13s(float(limiteInferior.get()),float(limiteSuperior.get()),eval(funcion.get()))
            valorReal=integralReal(eval(funcion.get()),float(limiteInferior.get()),float(limiteSuperior.get()))
            error=errorPorcentual(float(valorReal),float(valorAproximado))
            ingreso=["Simpsons 1/3 Simple",valorAproximado,valorReal,error]
            metodo.append(ingreso)
        if chkTercioCompuesto.get()==1:
            if (limiteSuperior.get()!="" and limiteInferior.get()!="") and intervalos.get()!="":
                valorAproximado=simpsons13c(float(limiteInferior.get()),float(limiteSuperior.get()),eval(funcion.get()),int(intervalos.get()))
                valorReal=integralReal(eval(funcion.get()),float(limiteInferior.get()),float(limiteSuperior.get()))
                error=errorPorcentual(float(valorReal),float(valorAproximado))
                ingreso=["Simpsons 1/3 compuesto",valorAproximado,valorReal,error]
                metodo.append(ingreso)
            else:
                messagebox.showerror("Error","Debe completar los campos")
        if chkOctavoSimple.get()==1:
            valorAproximado=simpsons18s(float(limiteInferior.get()),float(limiteSuperior.get()),eval(funcion.get()))
            valorReal=integralReal(eval(funcion.get()),float(limiteInferior.get()),float(limiteSuperior.get()))
            error=errorPorcentual(float(valorReal),float(valorAproximado))
            ingreso=["Simpsons 3/8 Simple",valorAproximado,valorReal,error]
            metodo.append(ingreso)
        if chkOctavoCompuesto.get()==1:
            if (limiteSuperior.get()!="" and limiteInferior.get()!="") and intervalos.get()!="":
                valorAproximado=simpsons18c(float(limiteInferior.get()),float(limiteSuperior.get()),eval(funcion.get()),int(intervalos.get()))
                valorReal=integralReal(eval(funcion.get()),float(limiteInferior.get()),float(limiteSuperior.get()))
                error=errorPorcentual(float(valorReal),float(valorAproximado))
                ingreso=["Simpsons 3/8 compuesto",valorAproximado,valorReal,error]
                metodo.append(ingreso)
        #Prograar aqui los metodo de integracion faltantes
            else:
                messagebox.showerror("Error","Debe completar los campos")
        #Integrales
        
        
        for i in range(0,len(metodo)):
            tbl.insert("",i,text=metodo[i][0],values=(metodo[i][1],metodo[i][2],metodo[i][3]))    
    else:
         messagebox.showerror("Error","Debe completar los campos")

#Muestra los controles necesarios para el metodo de richarson
def mostrarControles():
    #Trapecio simple
        lblNiveles.grid(row=4,column=1)
        txtNiveles.grid(row=4,column=2)

#Muestra los controles necesarioa para capturas los niveles al clickear los metodos compuesto de integracion
def verControlesIntegrales():
    lblIntervalos.grid(row=2,column=0)
    txtIntervalos.grid(row=2,column=1)

#Limpia todo
def limpiar():
    funcion.set("")
    h.set("")
    x0.set("")
    niveles.set("")
    tbl.delete(*tbl.get_children())
    limiteInferior.set("")
    limiteSuperior.set("")  
    intervalos.set("")
    chkdx1Adelante.set(0)
    chkdxx1Adelante.set(0)
    chkdxxx1Adelante.set(0)
    chkdlv1Adelante.set(0)
    chkorden2.set(0)
    chkRichar.set(0)
    chkdxx1Centrada.set(0)
    chkdxxx1Centrada.set(0)
    chkdlv1Centrada.set(0)
    chkdx1Atras.set(0)
    chkdxx1Atras.set(0)
    chkdxxx1Atras.set(0)
    chkdlv1Atras.set(0)
    chkdx2Adelante.set(0)
    chkdxx2Adelante.set(0)
    chkdxxx2Adelante.set(0)
    chkdlv2Adelante.set(0)
    
    chkdxx2Centrada.set(0)
    chkdxxx2Centrada.set(0)
    chkdlv2Centrada.set(0)
    chkdx2Atras.set(0)
    chkdxx2Atras.set(0)
    chkdxxx2Atras.set(0)
    chkdlv2Atras.set(0)
    chk5.set(0)
    chkorden4.set(0)
    chk3.set(0)
    chkTrapecioSimple.set(0)
    chkTrapecioCompuesto.set(0)
    chkTercioCompuesto.set(0)
    chkTercioSimple.set(0)
    chkTercioCompuesto.set(0)
    chkOctavoSimple.set(0)
    chkOctavoCompuesto.set(0)
    lblNiveles.grid_remove()
    txtNiveles.grid_remove()
    chkAdaptativo.set(0)
    chkCuadratura.set(0)
    chkRosember.set(0)
#def calcularDerivadas(event):
#Integrantes
Label(root,text="Cardona Castro, Julio César CC16046",font=("Arial Bold", 12)).pack(anchor=CENTER,side=TOP)
Label(root,text="Meda Margueiz, Christian Eduardo MM17017",font=("Arial Bold", 12)).pack(anchor=CENTER,side=TOP,)

#Frames
frameSeleccion=LabelFrame(root,text="Proceso")
frameSeleccion.pack(side=TOP)

frameDiferenciasSuperior=LabelFrame(root,text="N de derivada")
frameDiferenciacion=LabelFrame(frameDiferenciasSuperior)
framePrimeraDerivada=LabelFrame(frameDiferenciasSuperior,text="Encontrar primera derivada")
frameSegundaDerivada=LabelFrame(frameDiferenciasSuperior,text="Encontrar segunda derivada")
frameTerceraDerivada=LabelFrame(frameDiferenciasSuperior,text="Encontrar tercera derivada")
frameCuartaDerivada=LabelFrame(frameDiferenciasSuperior,text="Encontrar cuarta derivada")
frameIntegracion=LabelFrame(root,text="Elija el metodo de integracion numerica que desea")
frameDatos=LabelFrame(root,text="Datos requeridos")

#Para ingresar la funcion
Label(frameSeleccion,text="Ingrese la funcion:").grid(row=1,column=0)
txtFuncion=Entry(frameSeleccion,textvariable=funcion,justify="left").grid(row=1,column=1)
Label(frameSeleccion,text="Ejemplo:").grid(row=2,column=0)
Label(frameSeleccion,text="(x**2)*cos(x)").grid(row=2,column=1)

#Elementos de control para deriva
Label(frameDatos,text="h").grid(row=1,column=0)
txth=Entry(frameDatos,textvariable=h,justify="left").grid(row=1,column=1)
Label(frameDatos,text="x0").grid(row=2,column=0)
txtx=Entry(frameDatos,textvariable=x0,justify="left").grid(row=2,column=1)
lblNiveles=Label(framePrimeraDerivada,text="Niveles")
txtNiveles=Entry(framePrimeraDerivada,textvariable=niveles,justify="left")
Button(frameDiferenciasSuperior,text="Cancelar",command=limpiar).pack(side=BOTTOM,expand=TRUE,fill=BOTH)
btnDerivada=Button(frameDiferenciasSuperior,text="Calcular derivada",pady=4,command=procesarCalculo).pack(side=BOTTOM,expand=TRUE,fill=BOTH)


#Checks para diferenciacion
#Diferenciacion hacia adelante
#Primera derivada

Checkbutton(framePrimeraDerivada,text="1era Diferencia Adelante",variable=chkdx1Adelante,onvalue=1,offvalue=0).grid(row=0,column=0)
Checkbutton(framePrimeraDerivada,text="2da Diferencia Adelante",variable=chkdx2Adelante,onvalue=1,offvalue=0).grid(row=1,column=0)

Checkbutton(framePrimeraDerivada,text="Diferencia centrada Orden2",variable=chkorden2,onvalue=1,offvalue=0,justify=LEFT).grid(row=0,column=1)
Checkbutton(framePrimeraDerivada,text="Diferencia centrada Orden4",variable=chkorden4,onvalue=1,offvalue=0,justify=LEFT).grid(row=1,column=1)
Checkbutton(framePrimeraDerivada,text="Diferencia 3 puntos",variable=chk3,onvalue=1,offvalue=0, justify=LEFT).grid(row=2,column=1)
Checkbutton(framePrimeraDerivada,text="Diferencia 5 puntos",variable=chk5,onvalue=1,offvalue=0, justify=LEFT).grid(row=3,column=1)
Checkbutton(framePrimeraDerivada,text="1er Diferencia Atras",variable=chkdx1Atras,onvalue=1,offvalue=0).grid(row=0,column=2)
Checkbutton(framePrimeraDerivada,text="2da Diferencia Atras",variable=chkdx2Atras,onvalue=1,offvalue=0).grid(row=1,column=2)
Checkbutton(framePrimeraDerivada,text="Por Richardson",variable=chkRichar,command=mostrarControles,onvalue=1,offvalue=0).grid(row=4,column=0)



#Segunda derivada
Checkbutton(frameSegundaDerivada,text="1era Diferencia Adelante",variable=chkdxx1Adelante,onvalue=1,offvalue=0,justify=LEFT).grid(row=0,column=0)
Checkbutton(frameSegundaDerivada,text="2era Diferencia Adelante",variable=chkdxx2Adelante,onvalue=1,offvalue=0,justify=LEFT).grid(row=1,column=0)
Checkbutton(frameSegundaDerivada,text="1era Diferencia centrada",variable=chkdxx1Centrada,onvalue=1,offvalue=0,justify=LEFT).grid(row=0,column=1)
Checkbutton(frameSegundaDerivada,text="2da Diferencia centrada",variable=chkdxx2Centrada,onvalue=1,offvalue=0,justify=LEFT).grid(row=1,column=1)
Checkbutton(frameSegundaDerivada,text="2da Diferencia Atras",variable=chkdxx1Atras,onvalue=1,offvalue=0,justify=LEFT).grid(row=0,column=2)
Checkbutton(frameSegundaDerivada,text="2da Diferencia Atras",variable=chkdxx2Atras,onvalue=1,offvalue=0,justify=LEFT).grid(row=1,column=2)

#Tercera derivada
Checkbutton(frameTerceraDerivada,text="1era Diferencia Adelante",variable=chkdxxx1Adelante,onvalue=1,offvalue=0,justify=LEFT).grid(row=0,column=0)
Checkbutton(frameTerceraDerivada,text="2era Diferencia Adelante",variable=chkdxxx2Adelante,onvalue=1,offvalue=0,justify=LEFT).grid(row=1,column=0)
Checkbutton(frameTerceraDerivada,text="1era Diferencia centrada",variable=chkdxxx1Centrada,onvalue=1,offvalue=0,justify=LEFT).grid(row=0,column=1)
Checkbutton(frameTerceraDerivada,text="2da Diferencia centrada",variable=chkdxxx2Centrada,onvalue=1,offvalue=0,justify=LEFT).grid(row=1,column=1)
Checkbutton(frameTerceraDerivada,text="2da Diferencia Atras",variable=chkdxxx1Atras,onvalue=1,offvalue=0,justify=LEFT).grid(row=0,column=2)
Checkbutton(frameTerceraDerivada,text="2da Diferencia Atras",variable=chkdxxx2Atras,onvalue=1,offvalue=0,justify=LEFT).grid(row=1,column=2)

#Cuarta derivda
Checkbutton(frameCuartaDerivada,text="1era Diferencia Adelante",variable=chkdlv1Adelante,onvalue=1,offvalue=0,justify=LEFT).grid(row=0,column=0)
Checkbutton(frameCuartaDerivada,text="2era Diferencia Adelante",variable=chkdlv2Adelante,onvalue=1,offvalue=0,justify=LEFT).grid(row=1,column=0)
Checkbutton(frameCuartaDerivada,text="1era Diferencia centrada",variable=chkdlv1Centrada,onvalue=1,offvalue=0,justify=LEFT).grid(row=0,column=1)
Checkbutton(frameCuartaDerivada,text="2da Diferencia centrada",variable=chkdlv2Centrada,onvalue=1,offvalue=0,justify=LEFT).grid(row=1,column=1)
Checkbutton(frameCuartaDerivada,text="2da Diferencia Atras",variable=chkdlv1Atras,onvalue=1,offvalue=0,justify=LEFT).grid(row=0,column=2)
Checkbutton(frameCuartaDerivada,text="2da Diferencia Atras",variable=chkdlv2Atras,onvalue=1,offvalue=0, justify=LEFT).grid(row=1,column=2)

#Controles para integrar
Label(frameIntegracion,text="Limite superior").grid(row=0,column=0)
txtLimiteSuperior=Entry(frameIntegracion,textvariable=limiteSuperior).grid(row=0,column=1)
Label(frameIntegracion,text="Limite inferior").grid(row=1,column=0)
txtLimiteSuperior=Entry(frameIntegracion,textvariable=limiteInferior).grid(row=1,column=1)

Checkbutton(frameIntegracion,text="Trapecio simple",variable=chkTrapecioSimple,onvalue=1,offvalue=0 ).grid(row=3,column=0)
Checkbutton(frameIntegracion,text="Trapecio Compuesto",variable=chkTrapecioCompuesto,onvalue=1,offvalue=0,command=verControlesIntegrales).grid(row=4,column=0)
Checkbutton(frameIntegracion,text="Simpson 1/3 Simple",variable=chkTercioSimple,onvalue=1,offvalue=0).grid(row=5,column=0)
Checkbutton(frameIntegracion,text="Simpson 1/3 Compuesto",variable=chkTercioCompuesto,onvalue=1,offvalue=0,command=verControlesIntegrales).grid(row=6,column=0)
Checkbutton(frameIntegracion,text="Simpson 3/8 simple",variable=chkOctavoSimple,onvalue=1,offvalue=0).grid(row=7,column=0)
Checkbutton(frameIntegracion,text="Simson 3/8 compuesto",variable=chkOctavoCompuesto,onvalue=1,offvalue=0,command=verControlesIntegrales).grid(row=8,column=0)


btnIntegrar=Button(frameIntegracion,text="Calcular Integral",pady=4,command=procesarCalculo,width=40).grid(row=12,column=0,columnspan=2)
Button(frameIntegracion,text="Cancelar",command=limpiar,width=40).grid(row=13,column=0,columnspan=2)
lblIntervalos=Label(frameIntegracion,text="Numero de Intervalos")
txtIntervalos=Entry(frameIntegracion,textvariable=intervalos)


#select para elegir la operacion
Label(frameSeleccion,text="Seleccione operacion").grid(row=0,column=0)
cmbProceso = ttk.Combobox(frameSeleccion,value=proceso,state="readonly",justify="center", width=18)
cmbProceso.current(0)
cmbProceso.grid(row=0,column=1)
cmbProceso.bind("<<ComboboxSelected>>", seleccionarProceso)
#select para elegir la derivada de orde superior a encontrar
cmbDerivada= ttk.Combobox(frameDiferenciacion,value=numeroDerivada,state="readonly",justify="center", width=18)
cmbDerivada.current(0)
cmbDerivada.pack(anchor=CENTER,side=RIGHT)
cmbDerivada.bind("<<ComboboxSelected>>", seleccionarNDerivada)

#Tabla
tbl = ttk.Treeview(root)
tbl.pack(side=BOTTOM)
tbl["columns"] = ("1","2","3")
tbl.heading('#0', text='Metodo')
tbl.heading('1', text='Valor proximado')
tbl.heading('2', text='Valor Real')
tbl.heading('3',text="Error %")



root.mainloop()